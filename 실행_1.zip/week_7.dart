import 'dart:html';

import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @Override
  widget build(BuildContext context) {
    return MaterialApp(
      title: 'First app',
      theme: ThemeData(primarySwatch: colors.blue), // ThemeData
      home: MyHomePage(),
    ); // MaterialApp
  }
}

class  MyHomePage extends StatelessWidget {
  @Override
  widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('First app')
      ), // AppBar
    
    ); // Scaffold
}